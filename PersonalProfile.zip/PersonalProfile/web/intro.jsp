<%@page contentType="text/html" pageEncoding="UTF-8"%>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Personal Details</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container">
            <!-- Header -->
            <h1>Personal Details</h1>
            <form action="index.html" method="GET" style="background: none; padding: 0; box-shadow: none; margin-bottom: 15px; text-align: center;">
                <input type="submit" value="Home">
            </form>
            <!-- Body -->
            <form action="PersonalServlet" method="POST">
                Full Name: <input type="text" name="fullname"><br>
                Nickname: <input type="text" name="nickname" /><br>
                Student ID: <input type="text" name="studID"><br>
                Programme: <input type="text" name="programme"><br>
                Email: <input type="text" name="email"><br>
                Hobbies: <input type="text" name="hobbies"><br>
                Short-self Introduction: <input type="text" name="bio"><br>
                Create Secret Pass: <input type="password" name="secretpass" /><br>
                <input type="submit" value="Display Me">
            </form>
        </div>
    </body>
</html>
