<%@page import="java.util.*, com.profile.model.*" pageEncoding="UTF-8"%>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Others Profile</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container">
        <h2>Others Profiles</h2>
        <form action="index.html" method="GET" style="background: none; padding: 0; box-shadow: none; margin-bottom: 15px; text-align: center;">
            <input type="submit" value="Home">
        </form>
        
        <!-- Display Cards only if !Profiles.isEmpty() -->
        <%
            List<Profile> profileList = DataStore.getProfiles();
            if (profileList.isEmpty()) {
                out.println("<p>No profiles has been created yet. Be the first to introduce yourself!</p>");
            } else {
                for (int i = 0; i < profileList.size(); i++) {
                    Profile p = profileList.get(i);
        %>
            
        <div class="profile-card" style="border: 1px solid #ccc; padding: 15px; margin-bottom: 15px; border-radius: 5px; position: relative;">
            <!-- Profiles Card -->
            <h3><%= p.getNickname() %>'s Profile</h3>
            <p><strong>Name:</strong> <%= p.getName() %></p>
            <p><strong>Student ID:</strong> <%= p.getStudId() %></p>
            <p><strong>Programme:</strong> <%= p.getProgramme() %></p>
            <p><strong>Email</strong> <%= p.getEmail() %></p>
            <p><strong>Hobbies:</strong> <%= p.getHobbies() %></p>
            <p><strong>Short-self Introduction:</strong> <%= p.getBio() %></p>

            <!-- Secret Pass Section -->
            <div style="background: #f9f9f9; padding: 10px; margin-top: 10px;">
                <form action="ManageProfileServlet" method="POST">
                    <label>Enter Secret Pass to Modify:</label><br>
                    <input type="password" name="inputSecretPass" placeholder="Secret Pass" required>
                    <br><br>
                    <!-- Edit and Delete Buttons-->
                    <button type="submit" name="action" value="edit" style="background-color: orange; color: white;">Edit</button>
                    <button type="submit" name="action" value="delete" style="background-color: red; color: white;">Delete</button>
                </form>
            </div>
        </div>
                        <% 
                } 
            } 
        %>
        </div>
    </body>
</html>
