package com.profile.model;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ManageProfileServlet extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String inputSecretPass = request.getParameter("inputSecretPass");
        String action = request.getParameter("action");
        
        List<Profile> p = DataStore.getProfiles();
        Profile matchedP = null;

        //check for the matching profile nickname and secret pass
        for (int i = 0; i < p.size(); i++) {
            Profile tempP = p.get(i);
            if (tempP.getSecretPass().equals(inputSecretPass)) {
                matchedP = tempP;
                break;
            }
        }

        //if mathing profile not found = error message 
        if (matchedP == null) {
            response.sendRedirect("others.jsp");
            return;
        }

        //if matching profile found = proceed
        if ("delete".equals(action)) {
            DataStore.getProfiles().remove(matchedP);
        } else if ("edit".equals(action)) {
            request.setAttribute("editProfile", matchedP);
            request.getRequestDispatcher("intro.jsp").forward(request, response);
            DataStore.getProfiles().remove(matchedP);
            return;
        }

        //after all done
        response.sendRedirect("others.jsp");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
