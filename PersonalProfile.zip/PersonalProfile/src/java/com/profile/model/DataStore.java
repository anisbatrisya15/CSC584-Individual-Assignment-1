package com.profile.model;

import java.util.ArrayList;
import java.util.List;

public class DataStore {
    private static List<Profile> profileList = new ArrayList<>();
    
    //getter
    public static List<Profile> getProfiles() {
        return profileList;
    }
    
    //setter
    public static void addProfile(Profile p) {
        profileList.add(p);
    }
    
    //delete operation
    public static boolean deleteProfile(String secretPass) {
        return profileList.removeIf((Profile p) -> p.getSecretPass().equals(secretPass)); 
    }
}