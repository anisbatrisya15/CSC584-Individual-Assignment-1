package com.profile.model;

public class Profile implements java.io.Serializable{
    private String name;
    private String studentId;
    private String programme;
    private String email;
    private String hobbies;
    private String bio;
    private String nickname;
    private String secretPass;

    // normal constructor
    public Profile(String name, String studentId, String programme, String email, String hobbies, String bio, String nickname, String secretPass) {
        this.name = name;
        this.studentId = studentId;
        this.programme = programme;
        this.email = email;
        this.hobbies = hobbies;
        this.bio = bio;
        this.nickname = nickname;
        this.secretPass = secretPass;
    }
    
    public void setName(String name){
        this.name = name;
    }
    public void setStudId(String studentId){
        this.studentId = studentId;
    }
    public void setProgramme(String programme){
        this.programme = programme;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public void setHobbies(String hobbies){
        this.hobbies = hobbies;
    }
    public void setBio(String bio){
        this.bio = bio;
    }
    public void setNickname(String nickname){
        this.nickname = nickname;
    }
    public void setSecretPass(String secretPass){
        this.secretPass = secretPass;
    }
    public String getName(){
        return name;
    }
    public String getStudId(){
        return studentId;
    }
    public String getProgramme(){
        return programme;
    }
    public String getEmail(){
        return email;
    }
    public String getHobbies(){
        return hobbies;
    }
    public String getBio(){
        return bio;
    }
    public String getNickname(){
        return nickname;
    }
    public String getSecretPass(){
        return secretPass;
    }
}
